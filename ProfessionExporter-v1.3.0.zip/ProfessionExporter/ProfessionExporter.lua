local ADDON_NAME = ...

ProfessionExporterDB = ProfessionExporterDB or {
    version = 1,
    characters = {}
}

local exportFrame
local exportEditBox

local function SafeText(value)
    value = tostring(value or "")
    value = value:gsub("\t", " ")
    value = value:gsub("\r", " ")
    value = value:gsub("\n", " ")
    return value
end

local function GetItemIDFromLink(link)
    if not link then return "" end
    return link:match("item:(%-?%d+)") or ""
end

local function GetSpellIDFromLink(link)
    if not link then return "" end
    return link:match("enchant:(%-?%d+)")
        or link:match("spell:(%-?%d+)")
        or ""
end

local function CharacterKey()
    local name = UnitName("player") or "Unknown"
    local realm = GetRealmName and GetRealmName() or ""
    if realm and realm ~= "" then
        return name .. "-" .. realm
    end
    return name
end

local function EnsureCharacter()
    local key = CharacterKey()
    ProfessionExporterDB.characters[key] = ProfessionExporterDB.characters[key] or {
        name = UnitName("player") or "Unknown",
        realm = GetRealmName and GetRealmName() or "",
        professions = {}
    }
    return ProfessionExporterDB.characters[key]
end

local function BuildMaterials(skillIndex)
    local mats = {}
    local count = GetTradeSkillNumReagents(skillIndex) or 0

    for reagentIndex = 1, count do
        local reagentName, _, reagentCount = GetTradeSkillReagentInfo(skillIndex, reagentIndex)
        local reagentLink = GetTradeSkillReagentItemLink(skillIndex, reagentIndex)
        local reagentItemID = GetItemIDFromLink(reagentLink)

        if reagentName then
            local piece = tostring(reagentCount or 0) .. "x " .. SafeText(reagentName)
            if reagentItemID ~= "" then
                piece = piece .. " [" .. reagentItemID .. "]"
            end
            table.insert(mats, piece)
        end
    end

    return table.concat(mats, "; ")
end

local function ScanCurrentProfession()
    local professionName, currentSkill, maxSkill = GetTradeSkillLine()
    if not professionName or professionName == "UNKNOWN" or professionName == "" then
        DEFAULT_CHAT_FRAME:AddMessage("|cffff5555ProfessionExporter:|r Open a profession window first.")
        return nil
    end

    local character = EnsureCharacter()
    local profession = {
        name = professionName,
        currentSkill = currentSkill or "",
        maxSkill = maxSkill or "",
        recipes = {}
    }

    local total = GetNumTradeSkills() or 0
    for i = 1, total do
        local recipeName, skillType = GetTradeSkillInfo(i)

        if recipeName and skillType ~= "header" then
            local itemLink = GetTradeSkillItemLink(i)
            local recipeLink = GetTradeSkillRecipeLink and GetTradeSkillRecipeLink(i) or nil

            local craftedItemName = ""
            if itemLink then
                craftedItemName = itemLink:match("%[(.-)%]") or recipeName
            else
                craftedItemName = recipeName
            end

            table.insert(profession.recipes, {
                recipe = recipeName,
                difficulty = skillType or "",
                craftedItem = craftedItemName,
                itemID = GetItemIDFromLink(itemLink),
                recipeSpellID = GetSpellIDFromLink(recipeLink),
                materials = BuildMaterials(i)
            })
        end
    end

    character.professions[professionName] = profession

    DEFAULT_CHAT_FRAME:AddMessage(
        "|cff33ff99ProfessionExporter:|r Saved " ..
        tostring(#profession.recipes) .. " recipes from " .. professionName .. "."
    )

    return profession
end

local function SortedKeys(t)
    local keys = {}
    for k in pairs(t or {}) do
        table.insert(keys, k)
    end
    table.sort(keys)
    return keys
end

local function BuildTSV(currentCharacterOnly)
    local rows = {}

    local characterKeys = {}
    if currentCharacterOnly then
        local key = CharacterKey()
        if ProfessionExporterDB.characters[key] then
            table.insert(characterKeys, key)
        end
    else
        characterKeys = SortedKeys(ProfessionExporterDB.characters)
    end

    for _, characterKey in ipairs(characterKeys) do
        local character = ProfessionExporterDB.characters[characterKey]
        local professionNames = SortedKeys(character.professions)

        for _, professionName in ipairs(professionNames) do
            local profession = character.professions[professionName]

            table.sort(profession.recipes, function(a, b)
                return (a.craftedItem or a.recipe or "") < (b.craftedItem or b.recipe or "")
            end)

            for _, recipe in ipairs(profession.recipes) do
                -- Export the profession-list recipe/service name rather than
                -- the resulting crafted item name. This preserves names such
                -- as "Transmute: Ametrine" instead of shortening them to
                -- "Ametrine", and handles all similar recipes consistently.
                local exportName = recipe.recipe or recipe.craftedItem or ""

                table.insert(rows, table.concat({
                    SafeText(character.name),
                    SafeText(exportName)
                }, "\t"))
            end
        end
    end

    return table.concat(rows, "\n")
end

local function CreateExportFrame()
    if exportFrame then return end

    exportFrame = CreateFrame("Frame", "ProfessionExporterFrame", UIParent)
    exportFrame:SetWidth(850)
    exportFrame:SetHeight(520)
    exportFrame:SetPoint("CENTER")
    exportFrame:SetFrameStrata("DIALOG")
    exportFrame:SetMovable(true)
    exportFrame:EnableMouse(true)
    exportFrame:RegisterForDrag("LeftButton")
    exportFrame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    exportFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)

    exportFrame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true,
        tileSize = 32,
        edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 }
    })

    local title = exportFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -16)
    title:SetText("Profession Exporter")

    local help = exportFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    help:SetPoint("TOPLEFT", 24, -46)
    help:SetPoint("TOPRIGHT", -24, -46)
    help:SetJustifyH("LEFT")
    help:SetText("Ctrl+A then Ctrl+C. Paste directly into Google Sheets or Excel.")

    local close = CreateFrame("Button", nil, exportFrame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -4, -4)

    local scrollFrame = CreateFrame("ScrollFrame", "ProfessionExporterScrollFrame", exportFrame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 24, -70)
    scrollFrame:SetPoint("BOTTOMRIGHT", -45, 50)

    exportEditBox = CreateFrame("EditBox", "ProfessionExporterEditBox", scrollFrame)
    exportEditBox:SetMultiLine(true)
    exportEditBox:SetAutoFocus(false)
    exportEditBox:SetFontObject(ChatFontNormal)
    exportEditBox:SetWidth(770)
    exportEditBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
        exportFrame:Hide()
    end)
    exportEditBox:SetScript("OnTextChanged", function(self)
        local text = self:GetText() or ""
        local _, newlineCount = text:gsub("\n", "\n")
        local lines = newlineCount + 1
        self:SetHeight(math.max(390, lines * 14 + 20))
    end)

    scrollFrame:SetScrollChild(exportEditBox)

    local selectAll = CreateFrame("Button", nil, exportFrame, "UIPanelButtonTemplate")
    selectAll:SetWidth(110)
    selectAll:SetHeight(24)
    selectAll:SetPoint("BOTTOMLEFT", 24, 18)
    selectAll:SetText("Select All")
    selectAll:SetScript("OnClick", function()
        exportEditBox:SetFocus()
        exportEditBox:HighlightText()
    end)

    local currentOnly = CreateFrame("Button", nil, exportFrame, "UIPanelButtonTemplate")
    currentOnly:SetWidth(170)
    currentOnly:SetHeight(24)
    currentOnly:SetPoint("LEFT", selectAll, "RIGHT", 8, 0)
    currentOnly:SetText("Current Character")
    currentOnly:SetScript("OnClick", function()
        exportEditBox:SetText(BuildTSV(true))
        exportEditBox:SetFocus()
        exportEditBox:HighlightText()
    end)

    local allCharacters = CreateFrame("Button", nil, exportFrame, "UIPanelButtonTemplate")
    allCharacters:SetWidth(150)
    allCharacters:SetHeight(24)
    allCharacters:SetPoint("LEFT", currentOnly, "RIGHT", 8, 0)
    allCharacters:SetText("All Characters")
    allCharacters:SetScript("OnClick", function()
        exportEditBox:SetText(BuildTSV(false))
        exportEditBox:SetFocus()
        exportEditBox:HighlightText()
    end)
end

local function ShowExport(currentCharacterOnly)
    CreateExportFrame()
    exportEditBox:SetText(BuildTSV(currentCharacterOnly))
    exportFrame:Show()
    exportEditBox:SetFocus()
    exportEditBox:HighlightText()
end

local function PrintHelp()
    DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99ProfessionExporter commands:|r")
    DEFAULT_CHAT_FRAME:AddMessage("|cffffff00/pexport|r - scan the currently open profession and show copyable export")
    DEFAULT_CHAT_FRAME:AddMessage("|cffffff00/pexport scan|r - scan the currently open profession")
    DEFAULT_CHAT_FRAME:AddMessage("|cffffff00/pexport show|r - show current character's saved professions")
    DEFAULT_CHAT_FRAME:AddMessage("|cffffff00/pexport all|r - show saved professions for all characters")
    DEFAULT_CHAT_FRAME:AddMessage("|cffffff00/pexport clear|r - clear saved profession data for this character")
end

SLASH_PROFESSIONEXPORTER1 = "/pexport"
SlashCmdList["PROFESSIONEXPORTER"] = function(msg)
    msg = string.lower(msg or "")
    msg = msg:gsub("^%s+", ""):gsub("%s+$", "")

    if msg == "" then
        local profession = ScanCurrentProfession()
        if profession then
            ShowExport(true)
        end
    elseif msg == "scan" then
        ScanCurrentProfession()
    elseif msg == "show" then
        ShowExport(true)
    elseif msg == "all" then
        ShowExport(false)
    elseif msg == "clear" then
        local key = CharacterKey()
        ProfessionExporterDB.characters[key] = nil
        DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99ProfessionExporter:|r Cleared saved data for " .. key .. ".")
    else
        PrintHelp()
    end
end
