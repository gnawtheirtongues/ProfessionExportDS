Profession Exporter for WoW 3.3.5a / ChromieCraft
======================================================

VERSION 1.3
-----------
The exported name now always uses the recipe/service name shown in the
profession window instead of the resulting crafted item's name.

Examples:
Pissgrave    Transmute: Ametrine
Pissgrave    Transmute: Cardinal Ruby
Pissgrave    Swordguard Embroidery

This fixes recipes where the resulting item has a shorter/different name.

The export still has:
- No header row
- Column 1: Character
- Column 2: Recipe / Service name

INSTALL
-------
1. Extract the ProfessionExporter folder into:
   World of Warcraft\Interface\AddOns\
2. Replace the older ProfessionExporter folder.
3. Restart WoW or use /reload.

USE
---
1. Open a profession window.
2. Type /pexport
3. Press Ctrl+A, then Ctrl+C.
4. Paste into the ImportList sheet.
5. Repeat for each profession.

COMMANDS
--------
/pexport       Scan the currently open profession and show the export.
/pexport scan  Scan without opening the export window.
/pexport show  Show saved professions for the current character.
/pexport all   Show saved professions for all characters.
/pexport clear Clear saved profession data for the current character.
